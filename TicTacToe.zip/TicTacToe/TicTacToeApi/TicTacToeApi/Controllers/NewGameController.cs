﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace TicTacToeApi.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class NewGameController : ApiController
    {
        private Models.WinningCombinations _winningCombinations = new Models.WinningCombinations();
        
        [HttpPost]
        public Models.Game Post(Models.Move move)
        {            
            var gameDb = SaveGame(move);
            
            var winningLine = IsGameOver(gameDb);

            return new Models.Game {
                TicTacToeId = gameDb.TicTacToeId,
                WinningLine = winningLine
            };
        }

        private Game LoadGame(string ticTacToeId)
        {
            var result = new Game();

            using (var db = new TicTacToeEntities())
            {
                var games = db.Games.Where(t => t.TicTacToeId == ticTacToeId);

                if (games.Count() > 0)
                {
                    result = games.First();
                }
            }

            return result;
        }

        private Game SaveGame(Models.Move move)
        {
            var gameDb = new Game();

            //Check to see if the move has a TicTacToeID
            //If it is empty then this is seen as a new game
            if (string.IsNullOrEmpty(move.TicTacToeId))
            {
                move.TicTacToeId = Guid.NewGuid().ToString();
            }

            //Save the move to the Db
            using (var db = new TicTacToeEntities())
            {
                //Check to see if a current game exists
                var currentGame = db.Games.Where(g => g.TicTacToeId ==  move.TicTacToeId.Trim());

                //If the current game does not exist then create a new one
                if (currentGame.Count() == 0)
                {
                    gameDb = new Game();

                    gameDb.TicTacToeId = move.TicTacToeId;

                    db.Games.Add(gameDb);

                    db.SaveChanges();
                }
                else
                {
                    gameDb = currentGame.First();
                }

                gameDb.Moves.Add(new Move
                {
                    DateCreated = DateTime.Now,
                    Col = move.Col,
                    Row = move.Row,
                    Type = move.Type
                });

                db.SaveChanges();
            }

            return gameDb;
        }

        private List<Models.GridPoint> IsGameOver(Game game)
        {
            var result = new List<Models.GridPoint>();

            foreach (var winningLine in _winningCombinations.WinningLines)
            {
                var matchedMoves = new List<Move>();

                foreach (var gridPoint in winningLine.GridPoints)
                {                
                    //Get all moves in the current game that match a winning line 
                    //and check to see if the type is the same
                    foreach (var move in game.Moves)
                    {
                        if (move.Row == gridPoint.Row && move.Col == gridPoint.Col)
                        {
                            matchedMoves.Add(move);

                            //If we have 3 matched moves then check the types
                            if (matchedMoves.Count == 3)
                            {
                                var type = matchedMoves[0].Type;
                                if (matchedMoves[1].Type == type && matchedMoves[0].Type == type)
                                {
                                    return winningLine.GridPoints;
                                }
                            }
                        }
                    }                                    
                }                
            }

            return  result;
        }        
    }
}
