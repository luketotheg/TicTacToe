﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TicTacToeApi.Models
{
    public class Game
    {
        public Game()
        {
            WinningLine = new List<GridPoint>();
        }

        public List<GridPoint> WinningLine { get; set; }
        public string TicTacToeId { get; set; }
    }
}