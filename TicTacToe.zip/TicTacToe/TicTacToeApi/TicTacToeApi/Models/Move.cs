﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TicTacToeApi.Models
{
    public class Move
    {
        public string TicTacToeId { get; set; }
        public int Row { get; set; }
        public int Col { get; set; }
        public string Type { get; set; }
    }
}