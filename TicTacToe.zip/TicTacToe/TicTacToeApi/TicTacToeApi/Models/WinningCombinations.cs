﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TicTacToeApi.Models
{
    public class WinningCombinations
    {
        public WinningCombinations(){
            WinningLines = new List<Models.WinningLine> {
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 0},
                        new Models.GridPoint{Row =0,Col = 1},
                        new Models.GridPoint{Row =0,Col = 2}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =1,Col = 0},
                        new Models.GridPoint{Row =1,Col = 1},
                        new Models.GridPoint{Row =1,Col = 2}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =2,Col = 0},
                        new Models.GridPoint{Row =2,Col = 1},
                        new Models.GridPoint{Row =2,Col = 2}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 0},
                        new Models.GridPoint{Row =1,Col = 0},
                        new Models.GridPoint{Row =2,Col = 0}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 1},
                        new Models.GridPoint{Row =1,Col = 1},
                        new Models.GridPoint{Row =2,Col = 1}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 2},
                        new Models.GridPoint{Row =1,Col = 2},
                        new Models.GridPoint{Row =2,Col = 2}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 0},
                        new Models.GridPoint{Row =1,Col = 1},
                        new Models.GridPoint{Row =2,Col = 2}
                    }
                },
                new Models.WinningLine{
                    GridPoints = new List<Models.GridPoint>{
                        new Models.GridPoint{Row =0,Col = 2},
                        new Models.GridPoint{Row =1,Col = 1},
                        new Models.GridPoint{Row =2,Col = 0}
                    }
                },
            };
        }

        public List<WinningLine> WinningLines;
    }

    public class WinningLine
    {
        public WinningLine() {
            GridPoints = new List<GridPoint>();
        }

        public List<GridPoint> GridPoints { get; set; }
    }

    public class GridPoint
    {
        public int Row { get; set; }
        public int Col { get; set; }
    }
}