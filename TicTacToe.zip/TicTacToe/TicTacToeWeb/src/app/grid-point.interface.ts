export interface GridPoint {
  Row: number;
  Col: number;
}
