export class Move {
	Row: number;
	Col: number;
	Type: string;
	TicTacToeId: string;
	
	constuctor(row: number, col: number, type: string, ticTacToeId: string) {
    this.Row = row;
    this.Col = col;
    this.Type = type;
    this.TicTacToeId = ticTacToeId
  }
}
