export interface WinningLine {	
	TicTacToeId: string;	
	WinningLine:GridPoint[];
}

interface GridPoint {
  Row: number;
  Col: number;
}
