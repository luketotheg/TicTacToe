import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Move } from '../move';
import { WinningLine } from '../winning-line.interface';
import { GridPoint } from '../grid-point.interface';

@Component({
  selector: 'app-tictactoe',
  templateUrl: './tictactoe.component.html',
  styleUrls: ['./tictactoe.component.css']
})

export class TicTacToeComponent implements OnInit {
  url: string = 'http://localhost:5560/api/newgame';
  currentType: string;
  ticTacToeId: string;
  game = [];
  gameFinished: boolean = false;
  message: string;
  
  constructor(private http: HttpClient) {
    this.initialiseGame();
  }

  ngOnInit() {
  }

  move(row: number, col: number) {

    if (this.game[row][col].type != "" || this.gameFinished) {
      return;
    }

    //let move = new Move(row, col, this.currentType ? "X" : true, false, this.ticTacToeId);
    let move = new Move();

    move.Row = row;
    move.Col = col;
    move.Type = this.currentType;
    move.TicTacToeId = this.ticTacToeId;

    this.game[row][col].type = this.currentType;
    
    this.makeMove(move);
    
    this.changeType();    
  }

  resetGame() {
    this.initialiseGame();
  }

  initialiseGame() {
    this.gameFinished = false;
    this.currentType = "X"
    this.ticTacToeId = "";
    this.message = "The current move is: ";
    this.game = [
      [{ row: 0, col: 0, type: "" }, { row: 0, col: 1, type: "" }, { row: 0, col: 2, type: "" }],
      [{ row: 1, col: 0, type: "" }, { row: 1, col: 1, type: "" }, { row: 1, col: 2, type: "" }],
      [{ row: 2, col: 0, type: "" }, { row: 2, col: 1, type: "" }, { row: 2, col: 2, type: "" }]
    ];
  }

  makeMove(move: Move) {
  
    const req = this.http.post<WinningLine>('http://localhost:5560/api/newgame', move)
      .subscribe(
      res => {        
        this.ticTacToeId = res.TicTacToeId;

        if (res.WinningLine.length == 3) {
          this.gameFinished = true;
          this.changeType();
          this.message = "The winner is: ";          
          this.highlightWinningLine(res.WinningLine);
          return;
        }
        
      },
      err => {
        console.log("Error occured");
      });
  }

  highlightWinningLine(winningLine: Array<GridPoint>)
  {
    this.game[winningLine[0].Row][winningLine[0].Col].class = "highlight";
    this.game[winningLine[0].Row][winningLine[0].Col].class = "highlight";
    this.game[winningLine[1].Row][winningLine[1].Col].class = "highlight";
    this.game[winningLine[1].Row][winningLine[1].Col].class = "highlight";
    this.game[winningLine[2].Row][winningLine[2].Col].class = "highlight";
    this.game[winningLine[2].Row][winningLine[2].Col].class = "highlight";        
  }

  changeType() {
    if (this.currentType == "X") {
      this.currentType = "O";
    }
    else {
      this.currentType = "X";
    }
  }
}
